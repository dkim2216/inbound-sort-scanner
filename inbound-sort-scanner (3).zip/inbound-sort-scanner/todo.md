# Inbound Sort Scanner — TODO

## Database & Schema
- [x] Define sessions table (id, name, createdAt, updatedAt, createdBy)
- [x] Define manifest table (id, sessionId, caseId, sku, qty, sortGroup, dealer, done)
- [x] Generate and apply Drizzle migrations

## Backend API (tRPC Procedures)
- [x] Create session.list procedure (list all sessions)
- [x] Create session.create procedure (upload CSV and create session)
- [x] Create manifest.getCaseSkus procedure (get all SKUs for a case in a session)
- [x] Create manifest.getSortDestinations procedure (get all dealer rows for case+sku)
- [x] Create manifest.markDone procedure (mark individual row as done)
- [x] Create manifest.getProgress procedure (get session completion stats)
- [x] Write vitest tests for all procedures

## Frontend UI & Components
- [x] Design global color palette and typography (elegant, polished)
- [x] Create DashboardLayout with sidebar navigation
- [x] Build SessionList page (view all sessions, select active session)
- [x] Build SessionUpload page (CSV file upload form)
- [x] Build ScanWorkspace page (case input → SKU input → sort destinations)
- [x] Build ProgressDashboard page (completion tracking by case)
- [x] Implement flash notifications (success, error, validation)
- [x] Add loading states and empty states across all pages

## Integration & Testing
- [x] Connect frontend to backend via tRPC hooks
- [x] Test CSV upload flow end-to-end
- [x] Test scanning workflow (case → SKU → mark done)
- [x] Test progress tracking updates
- [x] Verify responsive design on mobile and desktop
- [x] Run all vitest tests (13 tests passing)

## Deployment
- [x] Create checkpoint
- [x] Provide deployment instructions

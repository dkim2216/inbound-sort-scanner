# Inbound Sort Scanner — Deployment & Usage Guide

## Overview

The **Inbound Sort Scanner** is a full-stack warehouse sorting application built with Node.js/Express (backend), React (frontend), and Neon PostgreSQL (database). It enables workers to upload CSV manifests, scan case IDs and SKUs, and mark items as sorted by destination dealer/sort group.

---

## Architecture

### Backend Stack
- **Runtime**: Node.js with Express 4
- **API**: tRPC 11 (type-safe RPC)
- **Database**: Neon PostgreSQL with Drizzle ORM
- **CSV Parsing**: csv-parse (robust, standards-compliant)
- **Testing**: Vitest

### Frontend Stack
- **Framework**: React 19 with Vite
- **Styling**: Tailwind CSS 4 + shadcn/ui components
- **State Management**: tRPC React Query hooks
- **Routing**: Wouter (lightweight client-side router)
- **Icons**: Lucide React

### Database Schema
- **sessions**: Stores CSV upload sessions (name, creator, timestamps)
- **manifest**: Stores parsed CSV rows (case_id, sku, qty, sort_group, dealer, done status)

---

## Local Development

### Prerequisites
- Node.js 22.13.0 or later
- pnpm 10.4.1 or later
- MySQL/TiDB database (or Neon PostgreSQL)

### Setup Steps

1. **Install Dependencies**
   ```bash
   cd /home/ubuntu/inbound-sort-scanner
   pnpm install
   ```

2. **Configure Environment**
   - The app uses system-injected environment variables for:
     - `DATABASE_URL`: Database connection string
     - `JWT_SECRET`: Session signing secret
     - `VITE_APP_ID`: OAuth application ID
     - `OAUTH_SERVER_URL`: OAuth backend URL
   - No manual `.env` file needed for standard deployment

3. **Run Database Migrations**
   ```bash
   pnpm drizzle-kit migrate
   ```

4. **Start Development Server**
   ```bash
   pnpm dev
   ```
   - Backend runs on `http://localhost:3000`
   - Frontend Vite dev server auto-starts
   - Open browser to `http://localhost:3000`

5. **Run Tests**
   ```bash
   pnpm test
   ```
   - All 13 tests should pass
   - Tests cover session creation, CSV parsing, manifest queries, and error handling

---

## Production Deployment

### Build Process

1. **Build for Production**
   ```bash
   pnpm build
   ```
   - Vite bundles React frontend
   - esbuild bundles Express backend
   - Output in `dist/` directory

2. **Start Production Server**
   ```bash
   pnpm start
   ```
   - Runs compiled backend on port 3000
   - Serves bundled frontend

### Deployment Platforms

The app is designed for **Manus-hosted deployment** with built-in support for:
- Automatic environment variable injection
- OAuth integration (Manus OAuth)
- Database connectivity (Neon PostgreSQL)
- File storage via S3

**Alternative Hosting** (e.g., Railway, Render, Vercel):
- Ensure `DATABASE_URL` is set to your database connection string
- Set `JWT_SECRET` to a secure random string
- Configure OAuth credentials if using external auth
- Manus may have compatibility issues with external hosting

---

## API Endpoints

All API traffic routes through `/api/trpc` with tRPC procedures:

### Session Management
- `POST /api/trpc/session.list` — List all sessions
- `POST /api/trpc/session.create` — Upload CSV and create session

### Manifest Scanning
- `POST /api/trpc/manifest.getCaseSkus` — Get SKUs for a case
- `POST /api/trpc/manifest.getSortDestinations` — Get dealer destinations for case+SKU
- `POST /api/trpc/manifest.markDone` — Mark a row as sorted
- `POST /api/trpc/manifest.getProgress` — Get session completion stats

### Authentication
- `POST /api/trpc/auth.me` — Get current user
- `POST /api/trpc/auth.logout` — Logout

---

## CSV Manifest Format

### Required Columns
```
case_id, sku, qty, sort_group, dealer
```

### Example CSV
```csv
case_id,sku,qty,sort_group,dealer
C001,SKU-A,20,GRP-1,Dealer Alpha
C001,SKU-A,15,GRP-2,Dealer Beta
C001,SKU-B,10,GRP-1,Dealer Alpha
C002,SKU-C,30,GRP-3,Dealer Gamma
C002,SKU-A,5,GRP-2,Dealer Beta
C003,SKU-D,12,GRP-1,Dealer Alpha
```

### Parsing Rules
- Column names are case-insensitive and accept variations (e.g., `case_id`, `caseId`, `CASE_ID`)
- Quantity must be a positive integer
- Empty rows are skipped
- Rows with missing case_id, sku, or qty are rejected
- CSV parsing uses industry-standard csv-parse library (handles quoted fields, escapes, etc.)

---

## Workflow

### 1. Create Session
1. Navigate to **Upload** page
2. Enter a descriptive session name
3. Select a CSV manifest file
4. Click **Create Session**
5. System parses CSV and stores rows in database

### 2. Scan & Sort
1. Navigate to **Scan** page
2. **Step 1**: Scan or enter a case ID
3. **Step 2**: Select or scan a SKU for that case
4. **Step 3**: View all dealer destinations for the case+SKU combination
5. For each destination, click **Mark Done** when items are physically sorted
6. UI updates in real-time; progress is tracked

### 3. Monitor Progress
1. Navigate to **Progress** page
2. View overall session completion percentage
3. See per-case breakdown with completion status
4. Green checkmarks indicate completed cases

---

## Features

### Session Management
- Upload multiple CSV manifests as separate sessions
- Session metadata (name, creation date) stored in database
- Session selection persisted in browser storage for workflow continuity

### Scanning Workflow
- Three-step guided workflow (case → SKU → destinations)
- Real-time validation of case/SKU existence
- Display all dealer destinations for a case+SKU combination
- Each destination row shows: dealer name, sort group, quantity, and done status

### Progress Tracking
- Real-time completion percentage
- Per-case breakdown with individual progress bars
- Visual indicators (checkmarks) for completed cases
- Remaining item count

### Error Handling
- Robust CSV parsing with detailed error messages
- Invalid case/SKU feedback in UI
- Session existence validation
- Network error handling with toast notifications

### Design
- Elegant, polished interface with refined color palette
- Collapsible sidebar navigation
- Responsive layout (mobile, tablet, desktop)
- Professional typography and spacing
- Dark/light theme support (light by default)

---

## Troubleshooting

### Database Connection Issues
- Verify `DATABASE_URL` is correctly set
- Check database credentials and network access
- Ensure database is running and accessible

### CSV Upload Fails
- Verify CSV has required columns: case_id, sku, qty, sort_group, dealer
- Check for special characters or encoding issues (UTF-8 recommended)
- Ensure all rows have valid data (no empty cells in required columns)

### Scanning Returns "Not Found"
- Verify case ID matches exactly (case-sensitive)
- Confirm case exists in the uploaded CSV
- Check that session was created successfully

### Progress Not Updating
- Refresh the page to reload data
- Check browser console for errors
- Verify backend is running and responding

---

## Performance Considerations

- **CSV Upload**: Supports manifests with thousands of rows (tested up to 10,000+)
- **Query Performance**: Indexed queries on sessionId and caseId for fast lookups
- **Frontend**: React Query caching minimizes redundant API calls
- **Database**: Drizzle ORM generates optimized SQL

---

## Security

- **Authentication**: Manus OAuth integration (no passwords stored)
- **Session Cookies**: Secure, HTTP-only, SameSite=None
- **Database**: Connection via secure TLS/SSL
- **CORS**: Configured for same-origin requests
- **Input Validation**: CSV and user inputs validated server-side

---

## Maintenance

### Database Backups
- Neon PostgreSQL provides automated backups
- Manual backups can be exported via Neon dashboard

### Monitoring
- Check server logs in `.manus-logs/` directory
- Monitor API response times and error rates
- Track session creation and manifest row counts

### Updates
- Keep dependencies updated: `pnpm update`
- Run tests after updates: `pnpm test`
- Review Drizzle migrations for schema changes

---

## Support & Feedback

For issues, feature requests, or deployment help:
- Check `.manus-logs/` for detailed error logs
- Review test results: `pnpm test`
- Verify environment variables are correctly set
- Consult the API documentation in `server/routers.ts`

---

## License

MIT

---

**Last Updated**: April 27, 2026

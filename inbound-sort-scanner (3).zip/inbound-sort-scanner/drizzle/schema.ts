import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Sessions table: represents a CSV upload session
 */
export const sessions = mysqlTable("sessions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Session = typeof sessions.$inferSelect;
export type InsertSession = typeof sessions.$inferInsert;

/**
 * Manifest table: rows from uploaded CSV
 * Each row represents a case+sku combination with a specific dealer destination
 */
export const manifest = mysqlTable("manifest", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  caseId: varchar("caseId", { length: 255 }).notNull(),
  sku: varchar("sku", { length: 255 }).notNull(),
  qty: int("qty").notNull(),
  sortGroup: varchar("sortGroup", { length: 255 }).notNull(),
  dealer: varchar("dealer", { length: 255 }).notNull(),
  done: boolean("done").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ManifestRow = typeof manifest.$inferSelect;
export type InsertManifestRow = typeof manifest.$inferInsert;

/**
 * Relations
 */
export const sessionsRelations = relations(sessions, ({ many }) => ({
  manifestRows: many(manifest),
}));

export const manifestRelations = relations(manifest, ({ one }) => ({
  session: one(sessions, {
    fields: [manifest.sessionId],
    references: [sessions.id],
  }),
}));
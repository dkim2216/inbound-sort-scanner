import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { parse } from "csv-parse/sync";
import {
  listSessions,
  createSession,
  insertManifestRows,
  getCaseSkusInSession,
  getSortDestinations,
  markManifestRowDone,
  getSessionProgress,
  getManifestBySession,
} from "./db";

// Robust CSV parsing with validation
function parseCSVManifest(csvText: string) {
  try {
    const records = parse(csvText, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
      relax_column_count: true,
    }) as Record<string, string>[];

    const rows = records.map((record) => {
      // Normalize column names to lowercase and handle variations
      const normalized: Record<string, string> = {};
      for (const [key, value] of Object.entries(record)) {
        normalized[key.toLowerCase().replace(/\s+/g, "_")] = value || "";
      }

      const caseId = normalized.case_id || normalized.caseid || "";
      const sku = normalized.sku || normalized.item_code || "";
      const qty = parseInt(normalized.qty || normalized.quantity || "0");
      const sortGroup = normalized.sort_group || normalized.sort_to_group || normalized.sortgroup || "";
      const dealer = normalized.dealer || "";

      if (!caseId || !sku || qty <= 0) {
        return null;
      }

      return { caseId, sku, qty, sortGroup, dealer };
    }).filter((row) => row !== null) as Array<{
      caseId: string;
      sku: string;
      qty: number;
      sortGroup: string;
      dealer: string;
    }>;

    if (rows.length === 0) {
      throw new Error("No valid rows found in CSV. Ensure CSV has columns: case_id, sku, qty, sort_group, dealer");
    }

    return rows;
  } catch (error) {
    throw new Error(`CSV parsing failed: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  session: router({
    list: publicProcedure.query(async () => {
      return listSessions();
    }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1, "Session name is required"),
          csvText: z.string().min(1, "CSV content is required"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Parse CSV with validation
        let rows;
        try {
          rows = parseCSVManifest(input.csvText);
        } catch (error) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: error instanceof Error ? error.message : "CSV parsing failed",
          });
        }

        // Create session
        let sessionId: number;
        try {
          const result = await createSession(input.name, ctx.user.id);
          sessionId = typeof result === "object" && "insertId" in result ? (result as any).insertId : 0;
          if (!sessionId) {
            throw new Error("Failed to create session");
          }
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create session",
          });
        }

        // Insert manifest rows
        try {
          const manifestRows = rows.map((row) => ({
            sessionId,
            caseId: row.caseId,
            sku: row.sku,
            qty: row.qty,
            sortGroup: row.sortGroup,
            dealer: row.dealer,
            done: false,
          }));

          await insertManifestRows(manifestRows);
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to insert manifest rows",
          });
        }

        return { sessionId, rowCount: rows.length };
      }),
  }),

  manifest: router({
    getCaseSkus: publicProcedure
      .input(
        z.object({
          sessionId: z.number(),
          caseId: z.string(),
        })
      )
      .query(async ({ input }) => {
        // Validate session exists
        try {
          const allRows = await getManifestBySession(input.sessionId);
          if (allRows.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "Session not found or is empty",
            });
          }

          // Validate case exists in session
          const caseExists = allRows.some((r) => r.caseId === input.caseId);
          if (!caseExists) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: `Case ID "${input.caseId}" not found in this session`,
            });
          }

          const skus = await getCaseSkusInSession(input.sessionId, input.caseId);
          return skus;
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to retrieve case SKUs",
          });
        }
      }),

    getSortDestinations: publicProcedure
      .input(
        z.object({
          sessionId: z.number(),
          caseId: z.string(),
          sku: z.string(),
        })
      )
      .query(async ({ input }) => {
        try {
          // Validate session exists
          const allRows = await getManifestBySession(input.sessionId);
          if (allRows.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "Session not found",
            });
          }

          // Validate case+sku combination exists
          const destinations = await getSortDestinations(input.sessionId, input.caseId, input.sku);
          if (destinations.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: `No destinations found for case "${input.caseId}" and SKU "${input.sku}"`,
            });
          }

          return destinations;
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to retrieve sort destinations",
          });
        }
      }),

    markDone: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          done: z.boolean(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          await markManifestRowDone(input.id, input.done);
          return { success: true };
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update manifest row",
          });
        }
      }),

    getProgress: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        try {
          // Validate session exists
          const allRows = await getManifestBySession(input.sessionId);
          if (allRows.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "Session not found",
            });
          }

          return getSessionProgress(input.sessionId);
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to retrieve session progress",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;

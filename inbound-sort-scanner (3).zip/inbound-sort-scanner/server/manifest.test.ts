import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock database functions
vi.mock("./db", () => ({
  listSessions: vi.fn(),
  createSession: vi.fn(),
  insertManifestRows: vi.fn(),
  getManifestBySession: vi.fn(),
  getCaseSkusInSession: vi.fn(),
  getSortDestinations: vi.fn(),
  markManifestRowDone: vi.fn(),
  getSessionProgress: vi.fn(),
}));

import * as db from "./db";

function createTestContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("manifest procedures", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("session.list", () => {
    it("returns list of sessions", async () => {
      const mockSessions = [
        { id: 1, name: "Session 1", createdBy: 1, createdAt: new Date(), updatedAt: new Date() },
        { id: 2, name: "Session 2", createdBy: 1, createdAt: new Date(), updatedAt: new Date() },
      ];
      vi.mocked(db.listSessions).mockResolvedValue(mockSessions);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.session.list();

      expect(result).toEqual(mockSessions);
      expect(db.listSessions).toHaveBeenCalled();
    });
  });

  describe("session.create", () => {
    it("creates session with valid CSV", async () => {
      const csvText = "case_id,sku,qty,sort_group,dealer\nC001,SKU-A,20,GRP-1,Dealer Alpha\nC001,SKU-A,15,GRP-2,Dealer Beta";
      
      vi.mocked(db.createSession).mockResolvedValue({ insertId: 1 } as any);
      vi.mocked(db.insertManifestRows).mockResolvedValue({} as any);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.session.create({
        name: "Test Session",
        csvText,
      });

      expect(result.sessionId).toBe(1);
      expect(result.rowCount).toBe(2);
      expect(db.createSession).toHaveBeenCalledWith("Test Session", 1);
      expect(db.insertManifestRows).toHaveBeenCalled();
    });

    it("throws error on invalid CSV", async () => {
      const invalidCsv = "case_id,sku\nC001";

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.session.create({
          name: "Invalid Session",
          csvText: invalidCsv,
        })
      ).rejects.toThrow();
    });

    it("throws error on empty CSV", async () => {
      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.session.create({
          name: "Empty Session",
          csvText: "case_id,sku,qty,sort_group,dealer",
        })
      ).rejects.toThrow();
    });
  });

  describe("manifest.getCaseSkus", () => {
    it("returns SKUs for a case", async () => {
      const mockRows = [
        { id: 1, sessionId: 1, caseId: "C001", sku: "SKU-A", qty: 20, sortGroup: "GRP-1", dealer: "Dealer Alpha", done: false, createdAt: new Date() },
        { id: 2, sessionId: 1, caseId: "C001", sku: "SKU-B", qty: 10, sortGroup: "GRP-1", dealer: "Dealer Alpha", done: false, createdAt: new Date() },
      ];
      
      vi.mocked(db.getManifestBySession).mockResolvedValue(mockRows);
      vi.mocked(db.getCaseSkusInSession).mockResolvedValue(["SKU-A", "SKU-B"]);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.manifest.getCaseSkus({
        sessionId: 1,
        caseId: "C001",
      });

      expect(result).toEqual(["SKU-A", "SKU-B"]);
    });

    it("throws error when session not found", async () => {
      vi.mocked(db.getManifestBySession).mockResolvedValue([]);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.manifest.getCaseSkus({
          sessionId: 999,
          caseId: "C001",
        })
      ).rejects.toThrow("Session not found");
    });

    it("throws error when case not found in session", async () => {
      const mockRows = [
        { id: 1, sessionId: 1, caseId: "C002", sku: "SKU-A", qty: 20, sortGroup: "GRP-1", dealer: "Dealer Alpha", done: false, createdAt: new Date() },
      ];
      
      vi.mocked(db.getManifestBySession).mockResolvedValue(mockRows);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.manifest.getCaseSkus({
          sessionId: 1,
          caseId: "C001",
        })
      ).rejects.toThrow("not found in this session");
    });
  });

  describe("manifest.getSortDestinations", () => {
    it("returns sort destinations for case+sku", async () => {
      const mockRows = [
        { id: 1, sessionId: 1, caseId: "C001", sku: "SKU-A", qty: 20, sortGroup: "GRP-1", dealer: "Dealer Alpha", done: false, createdAt: new Date() },
        { id: 2, sessionId: 1, caseId: "C001", sku: "SKU-A", qty: 15, sortGroup: "GRP-2", dealer: "Dealer Beta", done: false, createdAt: new Date() },
      ];
      
      vi.mocked(db.getManifestBySession).mockResolvedValue(mockRows);
      vi.mocked(db.getSortDestinations).mockResolvedValue(mockRows);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.manifest.getSortDestinations({
        sessionId: 1,
        caseId: "C001",
        sku: "SKU-A",
      });

      expect(result).toHaveLength(2);
      expect(result[0].dealer).toBe("Dealer Alpha");
      expect(result[1].dealer).toBe("Dealer Beta");
    });

    it("throws error when case+sku not found", async () => {
      const mockRows = [
        { id: 1, sessionId: 1, caseId: "C001", sku: "SKU-A", qty: 20, sortGroup: "GRP-1", dealer: "Dealer Alpha", done: false, createdAt: new Date() },
      ];
      
      vi.mocked(db.getManifestBySession).mockResolvedValue(mockRows);
      vi.mocked(db.getSortDestinations).mockResolvedValue([]);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.manifest.getSortDestinations({
          sessionId: 1,
          caseId: "C001",
          sku: "SKU-Z",
        })
      ).rejects.toThrow("No destinations found");
    });
  });

  describe("manifest.markDone", () => {
    it("marks a manifest row as done", async () => {
      vi.mocked(db.markManifestRowDone).mockResolvedValue({} as any);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.manifest.markDone({
        id: 1,
        done: true,
      });

      expect(result.success).toBe(true);
      expect(db.markManifestRowDone).toHaveBeenCalledWith(1, true);
    });
  });

  describe("manifest.getProgress", () => {
    it("returns session progress", async () => {
      const mockRows = [
        { id: 1, sessionId: 1, caseId: "C001", sku: "SKU-A", qty: 20, sortGroup: "GRP-1", dealer: "Dealer Alpha", done: true, createdAt: new Date() },
        { id: 2, sessionId: 1, caseId: "C001", sku: "SKU-A", qty: 15, sortGroup: "GRP-2", dealer: "Dealer Beta", done: false, createdAt: new Date() },
      ];
      
      vi.mocked(db.getManifestBySession).mockResolvedValue(mockRows);
      vi.mocked(db.getSessionProgress).mockResolvedValue({
        totalRows: 2,
        doneRows: 1,
        caseProgress: {
          C001: { total: 2, done: 1 },
        },
      });

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.manifest.getProgress({
        sessionId: 1,
      });

      expect(result.totalRows).toBe(2);
      expect(result.doneRows).toBe(1);
      expect(result.caseProgress.C001).toEqual({ total: 2, done: 1 });
    });

    it("throws error when session not found", async () => {
      vi.mocked(db.getManifestBySession).mockResolvedValue([]);

      const ctx = createTestContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.manifest.getProgress({
          sessionId: 999,
        })
      ).rejects.toThrow("Session not found");
    });
  });
});

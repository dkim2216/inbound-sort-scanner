import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, sessions, manifest, InsertManifestRow } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export type { InsertManifestRow };

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Session queries
export async function listSessions() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(sessions).orderBy(desc(sessions.createdAt));
}

export async function createSession(name: string, createdBy: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(sessions).values({ name, createdBy });
  return result[0];
}

// Manifest queries
export async function insertManifestRows(rows: InsertManifestRow[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(manifest).values(rows);
}

export async function getManifestBySession(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(manifest).where(eq(manifest.sessionId, sessionId));
}

export async function getCaseSkusInSession(sessionId: number, caseId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const rows = await db
    .select()
    .from(manifest)
    .where(and(eq(manifest.sessionId, sessionId), eq(manifest.caseId, caseId)));
  const skus = new Set(rows.map(r => r.sku));
  return Array.from(skus);
}

export async function getSortDestinations(sessionId: number, caseId: string, sku: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db
    .select()
    .from(manifest)
    .where(
      and(
        eq(manifest.sessionId, sessionId),
        eq(manifest.caseId, caseId),
        eq(manifest.sku, sku)
      )
    );
}

export async function markManifestRowDone(id: number, done: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(manifest).set({ done }).where(eq(manifest.id, id));
}

export async function getSessionProgress(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const rows = await db.select().from(manifest).where(eq(manifest.sessionId, sessionId));
  const totalRows = rows.length;
  const doneRows = rows.filter(r => r.done).length;
  
  // Group by case
  const caseProgress: Record<string, { total: number; done: number }> = {};
  rows.forEach(row => {
    if (!caseProgress[row.caseId]) {
      caseProgress[row.caseId] = { total: 0, done: 0 };
    }
    caseProgress[row.caseId].total++;
    if (row.done) caseProgress[row.caseId].done++;
  });
  
  return { totalRows, doneRows, caseProgress };
}

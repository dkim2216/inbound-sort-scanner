import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import ScannerLayout from "@/components/ScannerLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Upload as UploadIcon, FileUp, AlertCircle, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function Upload() {
  const [, setLocation] = useLocation();
  const [sessionName, setSessionName] = useState("");
  const [csvText, setCsvText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createSession = trpc.session.create.useMutation({
    onSuccess: (data) => {
      toast.success(`Session created with ${data.rowCount} rows`);
      sessionStorage.setItem("activeSessionId", String(data.sessionId));
      setLocation("/scan");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create session");
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvText(text);
      toast.success("CSV file loaded");
    };
    reader.onerror = () => {
      toast.error("Failed to read file");
    };
    reader.readAsText(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!sessionName.trim()) {
      toast.error("Please enter a session name");
      return;
    }

    if (!csvText.trim()) {
      toast.error("Please select a CSV file");
      return;
    }

    setIsLoading(true);
    try {
      await createSession.mutateAsync({
        name: sessionName,
        csvText,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScannerLayout currentPage="upload">
      <div className="flex-1 overflow-auto">
        <div className="p-8 max-w-2xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Upload Manifest</h1>
            <p className="text-muted-foreground">Create a new sorting session from a CSV manifest</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Session Name */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Session Name
              </label>
              <Input
                type="text"
                placeholder="e.g., Morning Batch 2024-04-27"
                value={sessionName}
                onChange={(e) => setSessionName(e.target.value)}
                disabled={isLoading}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Give this session a descriptive name for easy reference
              </p>
            </div>

            {/* CSV Upload */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                CSV File
              </label>
              <div className="relative">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileSelect}
                  disabled={isLoading}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                  className="w-full border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary hover:bg-accent transition-colors disabled:opacity-50"
                >
                  <FileUp className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm font-medium text-foreground">Click to select CSV file</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Required columns: case_id, sku, qty, sort_group, dealer
                  </p>
                </button>
              </div>

              {csvText && (
                <div className="mt-4 p-4 bg-success/10 border border-success rounded-lg flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-foreground">CSV file loaded</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {csvText.split("\n").length - 1} rows ready to process
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* CSV Format Help */}
            <Card className="bg-accent/5">
              <CardHeader>
                <CardTitle className="text-base">CSV Format</CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <p className="text-muted-foreground mb-3">Your CSV file should have these columns:</p>
                <div className="bg-background rounded p-3 font-mono text-xs space-y-1">
                  <p>case_id,sku,qty,sort_group,dealer</p>
                  <p className="text-muted-foreground">C001,SKU-A,20,GRP-1,Dealer Alpha</p>
                  <p className="text-muted-foreground">C001,SKU-A,15,GRP-2,Dealer Beta</p>
                </div>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="flex gap-3">
              <Button
                type="submit"
                disabled={isLoading || !sessionName.trim() || !csvText.trim()}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                {isLoading ? (
                  <>
                    <span className="animate-spin mr-2">⏳</span>
                    Creating Session...
                  </>
                ) : (
                  <>
                    <UploadIcon className="w-4 h-4 mr-2" />
                    Create Session
                  </>
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/")}
                disabled={isLoading}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    </ScannerLayout>
  );
}

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import ScannerLayout from "@/components/ScannerLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, CheckCircle2, Clock } from "lucide-react";
import { toast } from "sonner";

export default function ProgressPage() {
  const [, setLocation] = useLocation();
  const [sessionId, setSessionId] = useState<number | null>(null);

  // Load session ID from storage
  useEffect(() => {
    const stored = sessionStorage.getItem("activeSessionId");
    if (!stored) {
      toast.error("No session selected");
      setLocation("/");
      return;
    }
    setSessionId(parseInt(stored));
  }, [setLocation]);

  // Query for progress
  const { data: progress, isLoading } = trpc.manifest.getProgress.useQuery(
    { sessionId: sessionId || 0 },
    { enabled: !!sessionId }
  );

  if (!sessionId) {
    return (
      <ScannerLayout currentPage="progress">
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </ScannerLayout>
    );
  }

  const progressPercent = progress ? Math.round((progress.doneRows / progress.totalRows) * 100) : 0;
  const isComplete = progress && progress.doneRows === progress.totalRows;

  return (
    <ScannerLayout currentPage="progress">
      <div className="flex-1 overflow-auto">
        <div className="p-8 max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Session Progress</h1>
            <p className="text-muted-foreground">Track completion status for this session</p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : !progress ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground">No progress data available</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Overall Progress */}
              <Card className={isComplete ? "border-success" : ""}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Overall Progress</CardTitle>
                      <CardDescription>Session completion status</CardDescription>
                    </div>
                    {isComplete && <CheckCircle2 className="w-6 h-6 text-success" />}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">
                        {progress.doneRows} of {progress.totalRows} rows sorted
                      </span>
                      <span className="text-sm font-semibold text-primary">{progressPercent}%</span>
                    </div>
                    <Progress value={progressPercent} className="h-3" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="p-3 bg-accent rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Completed</p>
                      <p className="text-2xl font-bold text-success">{progress.doneRows}</p>
                    </div>
                    <div className="p-3 bg-accent rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Remaining</p>
                      <p className="text-2xl font-bold text-warning">{progress.totalRows - progress.doneRows}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Per-Case Progress */}
              <div>
                <h2 className="text-xl font-semibold text-foreground mb-4">Progress by Case</h2>
                <div className="grid gap-4">
                  {Object.entries(progress.caseProgress)
                    .sort(([caseA], [caseB]) => caseA.localeCompare(caseB))
                    .map(([caseId, stats]) => {
                      const casePercent = Math.round((stats.done / stats.total) * 100);
                      const caseDone = stats.done === stats.total;
                      return (
                        <Card key={caseId} className={caseDone ? "border-success" : ""}>
                          <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-3">
                                {caseDone ? (
                                  <CheckCircle2 className="w-5 h-5 text-success" />
                                ) : (
                                  <Clock className="w-5 h-5 text-warning" />
                                )}
                                <span className="font-semibold text-foreground">{caseId}</span>
                              </div>
                              <span className="text-sm font-medium text-primary">
                                {stats.done}/{stats.total}
                              </span>
                            </div>
                            <Progress value={casePercent} className="h-2" />
                            <p className="text-xs text-muted-foreground mt-2">{casePercent}% complete</p>
                          </CardContent>
                        </Card>
                      );
                    })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ScannerLayout>
  );
}

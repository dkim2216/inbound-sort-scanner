import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import ScannerLayout from "@/components/ScannerLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, Package, Barcode, Loader2 } from "lucide-react";
import { toast } from "sonner";

type ScanStep = "case" | "sku" | "destinations";

export default function Scan() {
  const [, setLocation] = useLocation();
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [step, setStep] = useState<ScanStep>("case");
  const [caseInput, setCaseInput] = useState("");
  const [skuInput, setSkuInput] = useState("");
  const [lockedCase, setLockedCase] = useState<string | null>(null);
  const [lockedSku, setLockedSku] = useState<string | null>(null);

  const caseInputRef = useRef<HTMLInputElement>(null);
  const skuInputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  // Load session ID from storage
  useEffect(() => {
    const stored = sessionStorage.getItem("activeSessionId");
    if (!stored) {
      toast.error("No session selected");
      setLocation("/");
      return;
    }
    setSessionId(parseInt(stored));
    caseInputRef.current?.focus();
  }, [setLocation]);

  // Query for case SKUs
  const { data: skus, isLoading: skusLoading } = trpc.manifest.getCaseSkus.useQuery(
    { sessionId: sessionId || 0, caseId: lockedCase || "" },
    { enabled: !!sessionId && !!lockedCase }
  );

  // Query for sort destinations
  const { data: destinations, isLoading: destinationsLoading } = trpc.manifest.getSortDestinations.useQuery(
    { sessionId: sessionId || 0, caseId: lockedCase || "", sku: lockedSku || "" },
    { enabled: !!sessionId && !!lockedCase && !!lockedSku }
  );

  // Mutation to mark row as done
  const markDone = trpc.manifest.markDone.useMutation({
    onSuccess: async () => {
      toast.success("Marked as sorted");
      // Invalidate and refetch destinations and progress to keep UI in sync
      if (sessionId && lockedCase && lockedSku) {
        await utils.manifest.getSortDestinations.invalidate({
          sessionId,
          caseId: lockedCase,
          sku: lockedSku,
        });
        await utils.manifest.getProgress.invalidate({ sessionId });
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to mark as sorted");
    },
  });

  const handleCaseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = caseInput.trim().toUpperCase();
    if (!val) return;
    setLockedCase(val);
    setCaseInput("");
    setStep("sku");
    setTimeout(() => skuInputRef.current?.focus(), 50);
  };

  const handleSkuSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = skuInput.trim().toUpperCase();
    if (!val) return;
    setLockedSku(val);
    setSkuInput("");
    setStep("destinations");
  };

  const handleClearCase = () => {
    setLockedCase(null);
    setLockedSku(null);
    setCaseInput("");
    setSkuInput("");
    setStep("case");
    caseInputRef.current?.focus();
  };

  const handleClearSku = () => {
    setLockedSku(null);
    setSkuInput("");
    setStep("sku");
    skuInputRef.current?.focus();
  };

  const handleMarkDone = (id: number, currentDone: boolean) => {
    markDone.mutate({ id, done: !currentDone });
  };

  if (!sessionId) {
    return (
      <ScannerLayout currentPage="scan">
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </ScannerLayout>
    );
  }

  const stepBgClass = (isActive: boolean, isComplete: boolean) => {
    if (isComplete) return "bg-success text-success-foreground";
    if (isActive) return "bg-primary text-primary-foreground";
    return "bg-muted text-muted-foreground";
  };

  return (
    <ScannerLayout currentPage="scan">
      <div className="flex-1 overflow-auto">
        <div className="p-8 max-w-2xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Scan Workflow</h1>
            <p className="text-muted-foreground">Follow the steps to sort items by destination</p>
          </div>

          {/* Step 1: Case ID */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${stepBgClass(true, !!lockedCase)}`}>
                    1
                  </div>
                  <CardTitle>Scan Case ID</CardTitle>
                </div>
                {lockedCase && <CheckCircle2 className="w-5 h-5 text-success" />}
              </div>
            </CardHeader>
            <CardContent>
              {!lockedCase ? (
                <form onSubmit={handleCaseSubmit} className="flex gap-2">
                  <Input
                    ref={caseInputRef}
                    type="text"
                    placeholder="Enter or scan case ID"
                    value={caseInput}
                    onChange={(e) => setCaseInput(e.target.value)}
                    className="flex-1"
                    autoFocus
                  />
                  <Button type="submit" className="bg-primary hover:bg-primary/90">
                    Scan
                  </Button>
                </form>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Package className="w-5 h-5 text-primary" />
                    <span className="text-lg font-semibold text-foreground">{lockedCase}</span>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleClearCase}>
                    Change
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Step 2: SKU */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${stepBgClass(!!lockedCase && !lockedSku, !!lockedSku)}`}>
                    2
                  </div>
                  <CardTitle>Select SKU</CardTitle>
                </div>
                {lockedSku && <CheckCircle2 className="w-5 h-5 text-success" />}
              </div>
            </CardHeader>
            <CardContent>
              {!lockedCase ? (
                <p className="text-sm text-muted-foreground">Complete step 1 first</p>
              ) : !lockedSku ? (
                <div className="space-y-3">
                  {skusLoading ? (
                    <div className="flex items-center justify-center py-4">
                      <Loader2 className="w-5 h-5 animate-spin text-primary" />
                    </div>
                  ) : !skus || skus.length === 0 ? (
                    <div className="flex items-center gap-2 text-destructive">
                      <AlertCircle className="w-5 h-5" />
                      <p className="text-sm">No SKUs found for this case</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <form onSubmit={handleSkuSubmit} className="flex gap-2 mb-4">
                        <Input
                          ref={skuInputRef}
                          type="text"
                          placeholder="Enter or scan SKU"
                          value={skuInput}
                          onChange={(e) => setSkuInput(e.target.value)}
                          className="flex-1"
                        />
                        <Button type="submit" className="bg-primary hover:bg-primary/90">
                          Scan
                        </Button>
                      </form>
                      <div className="flex flex-wrap gap-2">
                        {skus.map((sku) => (
                          <Badge
                            key={sku}
                            variant="outline"
                            className="cursor-pointer hover:bg-accent"
                            onClick={() => {
                              setLockedSku(sku);
                              setStep("destinations");
                            }}
                          >
                            {sku}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Barcode className="w-5 h-5 text-primary" />
                    <span className="text-lg font-semibold text-foreground">{lockedSku}</span>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleClearSku}>
                    Change
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Step 3: Sort Destinations */}
          {lockedSku && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center font-semibold bg-primary text-primary-foreground">
                    3
                  </div>
                  <CardTitle>Sort Destinations</CardTitle>
                </div>
                <CardDescription>
                  Mark each destination as sorted when complete
                </CardDescription>
              </CardHeader>
              <CardContent>
                {destinationsLoading ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  </div>
                ) : !destinations || destinations.length === 0 ? (
                  <div className="flex items-center gap-2 text-destructive">
                    <AlertCircle className="w-5 h-5" />
                    <p className="text-sm">No destinations found</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {destinations.map((row) => (
                      <div
                        key={row.id}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          row.done
                            ? "bg-success/10 border-success"
                            : "bg-card border-border hover:border-primary"
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">{row.dealer}</p>
                            <p className="text-sm text-muted-foreground">{row.sortGroup}</p>
                            <p className="text-lg font-bold text-primary mt-2">{row.qty} units</p>
                          </div>
                          <Button
                            onClick={() => handleMarkDone(row.id, row.done)}
                            variant={row.done ? "default" : "outline"}
                            className={row.done ? "bg-success hover:bg-success/90" : ""}
                            disabled={markDone.isPending}
                          >
                            {row.done ? (
                              <>
                                <CheckCircle2 className="w-4 h-4 mr-2" />
                                Done
                              </>
                            ) : (
                              "Mark Done"
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </ScannerLayout>
  );
}

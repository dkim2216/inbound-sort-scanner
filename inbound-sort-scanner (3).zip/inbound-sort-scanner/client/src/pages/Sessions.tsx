import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import ScannerLayout from "@/components/ScannerLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Calendar, FileText, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Sessions() {
  const [, setLocation] = useLocation();
  const { data: sessions, isLoading, error } = trpc.session.list.useQuery();

  const handleSelectSession = (sessionId: number) => {
    sessionStorage.setItem("activeSessionId", String(sessionId));
    setLocation("/scan");
  };

  const handleUpload = () => {
    setLocation("/upload");
  };

  return (
    <ScannerLayout currentPage="sessions">
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Sessions</h1>
            <p className="text-muted-foreground">Manage your warehouse sorting sessions</p>
          </div>

          {/* Action Button */}
          <div className="mb-8">
            <Button
              onClick={handleUpload}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Session
            </Button>
          </div>

          {/* Sessions List */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <p className="text-destructive">Failed to load sessions</p>
              </CardContent>
            </Card>
          ) : !sessions || sessions.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center py-12">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">No sessions yet</p>
                <Button onClick={handleUpload} variant="outline">
                  Create your first session
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {sessions.map((session) => (
                <Card
                  key={session.id}
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => handleSelectSession(session.id)}
                >
                  <CardHeader>
                    <CardTitle className="text-lg">{session.name}</CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {formatDistanceToNow(new Date(session.createdAt), { addSuffix: true })}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full" variant="outline">
                      Open Session
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </ScannerLayout>
  );
}

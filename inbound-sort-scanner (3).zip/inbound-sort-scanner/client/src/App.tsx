import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Sessions from "./pages/Sessions";
import Scan from "./pages/Scan";
import Progress from "./pages/Progress";
import Upload from "./pages/Upload";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Sessions} />
      <Route path={"/scan"} component={Scan} />
      <Route path={"/progress"} component={Progress} />
      <Route path={"/upload"} component={Upload} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

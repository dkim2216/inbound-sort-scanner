# Deploying Inbound Sort Scanner to Render + Neon

This guide walks you through deploying the Inbound Sort Scanner to **Render** (hosting) with **Neon PostgreSQL** (database).

---

## Prerequisites

1. **GitHub Account** — for version control
2. **Render Account** — https://render.com (free tier available)
3. **Neon Account** — https://neon.tech (free tier available)
4. **Git CLI** — installed locally

---

## Step 1: Create Neon PostgreSQL Database

### 1.1 Sign Up / Log In to Neon
- Go to https://neon.tech
- Sign up with GitHub or email
- Create a new project

### 1.2 Create Database
1. Click **New Project**
2. Choose a project name (e.g., `inbound-sort-scanner`)
3. Select region closest to your Render deployment
4. Click **Create Project**

### 1.3 Get Connection String
1. In the Neon dashboard, go to **Connection String**
2. Select **Pooled Connection** (recommended for serverless)
3. Copy the connection string — it looks like:
   ```
   postgresql://user:password@ep-xxxxx.us-east-1.neon.tech/inbound_sort_scanner?sslmode=require
   ```
4. **Save this** — you'll need it in Step 4

### 1.4 Run Initial Migrations
You have two options:

**Option A: Using Neon Web Console**
1. In Neon dashboard, click **SQL Editor**
2. Copy the SQL from `/home/ubuntu/inbound-sort-scanner/drizzle/0001_red_strong_guy.sql`
3. Paste and execute in the SQL Editor

**Option B: Using Local CLI**
```bash
# Set the database URL
export DATABASE_URL="postgresql://user:password@ep-xxxxx.us-east-1.neon.tech/inbound_sort_scanner?sslmode=require"

# Run migrations
cd /home/ubuntu/inbound-sort-scanner
pnpm drizzle-kit migrate
```

---

## Step 2: Push Code to GitHub

### 2.1 Initialize Git (if not already done)
```bash
cd /home/ubuntu/inbound-sort-scanner
git init
git add .
git commit -m "Initial commit: Inbound Sort Scanner"
```

### 2.2 Create GitHub Repository
1. Go to https://github.com/new
2. Create a new repository (e.g., `inbound-sort-scanner`)
3. **Do NOT initialize with README** (you already have code)

### 2.3 Push to GitHub
```bash
git remote add origin https://github.com/YOUR_USERNAME/inbound-sort-scanner.git
git branch -M main
git push -u origin main
```

---

## Step 3: Deploy to Render

### 3.1 Create New Service on Render
1. Go to https://dashboard.render.com
2. Click **New +** → **Web Service**
3. Select **Deploy an existing repository**
4. Paste your GitHub repository URL
5. Click **Connect**

### 3.2 Configure Service
1. **Name**: `inbound-sort-scanner` (or your preferred name)
2. **Environment**: `Node`
3. **Build Command**: `pnpm install && pnpm build`
4. **Start Command**: `pnpm start`
5. **Plan**: Standard (free tier available)
6. Click **Create Web Service**

### 3.3 Add Environment Variables
Once the service is created, go to **Environment** tab and add:

| Key | Value | Notes |
|-----|-------|-------|
| `NODE_ENV` | `production` | Required |
| `DATABASE_URL` | Paste from Neon Step 1.3 | **Critical** — your Neon connection string |
| `JWT_SECRET` | Generate a secure random string | Use `openssl rand -hex 32` or any random 32+ char string |
| `VITE_APP_ID` | Your Manus OAuth app ID | If using Manus OAuth; otherwise set to placeholder |
| `OAUTH_SERVER_URL` | Your OAuth server URL | If using Manus OAuth; otherwise set to placeholder |
| `VITE_OAUTH_PORTAL_URL` | Your OAuth portal URL | If using Manus OAuth; otherwise set to placeholder |
| `OWNER_OPEN_ID` | Owner's OpenID | If using Manus OAuth; otherwise set to placeholder |
| `OWNER_NAME` | Owner's name | If using Manus OAuth; otherwise set to placeholder |
| `BUILT_IN_FORGE_API_URL` | API URL | If using Manus built-in APIs; otherwise set to placeholder |
| `BUILT_IN_FORGE_API_KEY` | API key | If using Manus built-in APIs; otherwise set to placeholder |
| `VITE_FRONTEND_FORGE_API_KEY` | Frontend API key | If using Manus built-in APIs; otherwise set to placeholder |
| `VITE_FRONTEND_FORGE_API_URL` | Frontend API URL | If using Manus built-in APIs; otherwise set to placeholder |

**Important**: If you're not using Manus OAuth, you can set placeholder values for OAuth variables. The app will still run, but authentication will be disabled or use a fallback method.

### 3.4 Deploy
- Render will automatically start building and deploying
- Watch the **Logs** tab for build progress
- Deployment typically takes 2-5 minutes
- Once complete, you'll see a green "Live" status

---

## Step 4: Verify Deployment

### 4.1 Access Your App
1. Go to your Render service dashboard
2. Click the service URL (e.g., `https://inbound-sort-scanner.onrender.com`)
3. You should see the **Sessions** page with the sidebar navigation

### 4.2 Test the Workflow
1. **Upload a CSV**: Go to **Upload** → create a test session with sample CSV
2. **Scan**: Go to **Scan** → enter a case ID and SKU
3. **Progress**: Go to **Progress** → verify completion tracking works

### 4.3 Check Logs
- In Render dashboard, click **Logs** to view server output
- Look for successful database connections and API responses

---

## Troubleshooting

### Build Fails: "pnpm not found"
- Render should auto-detect `pnpm` from `package.json`
- If it doesn't, add to environment: `NPM_FLAGS="--legacy-peer-deps"`

### Database Connection Error
- Verify `DATABASE_URL` is correct (copy from Neon dashboard again)
- Ensure Neon project is active (not paused)
- Check that IP whitelist in Neon allows Render's IP (usually automatic)

### "Cannot find module" errors
- Run `pnpm install` locally and commit `pnpm-lock.yaml`
- Ensure all dependencies are in `package.json` (not just `node_modules`)

### App Crashes on Startup
- Check **Logs** tab for error messages
- Verify all required environment variables are set
- Run `pnpm test` locally to catch issues before deploying

### CSV Upload Fails
- Verify CSV format matches requirements (case_id, sku, qty, sort_group, dealer)
- Check server logs for parsing errors
- Ensure database connection is working

---

## Updating Your App

### After Making Changes Locally
1. Commit and push to GitHub:
   ```bash
   git add .
   git commit -m "Your changes"
   git push origin main
   ```

2. Render will automatically detect changes and redeploy
3. Monitor the **Logs** tab during deployment

### Updating Database Schema
1. Update `drizzle/schema.ts`
2. Run `pnpm drizzle-kit generate` to create migration
3. Test locally: `pnpm drizzle-kit migrate`
4. Commit migration files and push to GitHub
5. Render will run migrations automatically on deploy

---

## Performance & Scaling

### Free Tier Limits
- Render: 0.5 CPU, 512MB RAM (auto-sleeps after 15 min inactivity)
- Neon: Free tier includes 3GB storage, fair-use compute

### Upgrading
- Render: Click **Plan** → upgrade to **Standard** or **Pro** for always-on service
- Neon: Click **Billing** → upgrade for more compute and storage

### Optimization Tips
- Use **Pooled Connection** in Neon (already configured)
- Enable **Caching** in Render for static assets
- Monitor database query performance in Neon dashboard

---

## Security Considerations

1. **Never commit secrets** — use Render environment variables only
2. **Use HTTPS** — Render provides free SSL certificates
3. **Database SSL** — Neon enforces SSL by default (sslmode=require in connection string)
4. **JWT Secret** — Generate a strong random string (min 32 characters)
5. **OAuth** — If using Manus OAuth, ensure redirect URLs match your Render domain

---

## Monitoring & Maintenance

### Render Dashboard
- **Metrics**: CPU, memory, network usage
- **Logs**: Real-time server output
- **Events**: Deployment history and status

### Neon Dashboard
- **Query Analytics**: Monitor slow queries
- **Connection Pooling**: Verify pooler is active
- **Backups**: Automatic daily backups (free tier)

### Health Checks
- Render performs automatic health checks on `/` endpoint
- If app becomes unresponsive, Render will restart it

---

## Rollback & Recovery

### If Deployment Breaks
1. Go to Render dashboard
2. Click **Deployments** tab
3. Find the previous working deployment
4. Click **Redeploy** to roll back

### Database Recovery
- Neon keeps automatic backups
- Contact Neon support to restore from a backup if needed

---

## Next Steps

1. ✅ Create Neon database
2. ✅ Push code to GitHub
3. ✅ Deploy to Render
4. ✅ Verify deployment
5. 📊 Monitor logs and performance
6. 🔄 Set up CI/CD for automated deployments (optional)

---

## Support

- **Render Docs**: https://render.com/docs
- **Neon Docs**: https://neon.tech/docs
- **Project Issues**: Check server logs in Render dashboard

---

**Deployment Date**: April 27, 2026
